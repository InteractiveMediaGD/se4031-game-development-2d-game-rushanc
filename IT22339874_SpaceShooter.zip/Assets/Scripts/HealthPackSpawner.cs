using UnityEngine;

public class HealthPackSpawner : MonoBehaviour
{
    public GameObject healthPackPrefab;

    public float spawnInterval = 6f;
    public float spawnX = 8f;
    public float minY = -2f;
    public float maxY = 2f;

    private float timer = 0f;

    void Update()
    {
        timer += Time.deltaTime;

        if (timer >= spawnInterval)
        {
            SpawnHealthPack();
            timer = 0f;
        }
    }

    void SpawnHealthPack()
    {
        float randomY = Random.Range(minY, maxY);

        Instantiate(
            healthPackPrefab,
            new Vector3(spawnX, randomY, 0f),
            Quaternion.identity
        );
    }
}