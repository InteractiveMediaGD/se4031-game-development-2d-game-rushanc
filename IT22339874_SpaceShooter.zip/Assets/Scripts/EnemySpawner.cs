using UnityEngine;

public class EnemySpawner : MonoBehaviour
{
    public GameObject enemyPrefab;

    public float spawnInterval = 4f;
    public float spawnX = 8f;
    public float minY = -3f;
    public float maxY = 3f;

    private float timer = 0f;

    void Update()
    {
        timer += Time.deltaTime;

        if (timer >= spawnInterval)
        {
            SpawnEnemy();
            timer = 0f;
        }
    }

    void SpawnEnemy()
    {
        float randomY = Random.Range(minY, maxY);

        Instantiate(
            enemyPrefab,
            new Vector3(spawnX, randomY, 0f),
            Quaternion.identity
        );
    }
}