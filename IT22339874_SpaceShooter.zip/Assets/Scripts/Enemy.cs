using UnityEngine;

public class Enemy : MonoBehaviour
{
    [Header("Enemy Settings")]
    public int damageAmount = 20;
    public int scoreAmount = 2;

    private void OnTriggerEnter2D(Collider2D other)
    {
        // Player touches enemy
        if (other.CompareTag("Player"))
        {
            PlayerHealth playerHealth = other.GetComponent<PlayerHealth>();

            if (playerHealth != null)
            {
                playerHealth.TakeDamage(damageAmount);
            }

            Destroy(gameObject);
        }

        // Projectile touches enemy
        if (other.CompareTag("Projectile"))
        {
            if (GameManager.Instance != null)
            {
                GameManager.Instance.AddScore(scoreAmount);
            }

            Destroy(other.gameObject); // destroy projectile
            Destroy(gameObject);       // destroy enemy
        }
    }
}
