using UnityEngine;

public class MoveLeft : MonoBehaviour
{
    public float speedMultiplier = 1f;
    public float destroyX = -15f;

    void Update()
    {
        float currentSpeed = 4f;

        if (GameManager.Instance != null)
        {
            currentSpeed = GameManager.Instance.gameSpeed;
        }

        transform.Translate(Vector3.left * currentSpeed * speedMultiplier * Time.deltaTime, Space.World);

        if (transform.position.x < destroyX)
        {
            Destroy(gameObject);
        }
    }
}