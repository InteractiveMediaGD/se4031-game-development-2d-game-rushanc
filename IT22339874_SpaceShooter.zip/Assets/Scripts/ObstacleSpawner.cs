using UnityEngine;

public class ObstacleSpawner : MonoBehaviour
{
    public GameObject obstaclePairPrefab;

    [Header("Spawn Settings")]
    public float spawnInterval = 2f;
    public float spawnX = 12f;

    [Header("Random Height Settings")]
    public float minY = -2f;
    public float maxY = 2f;

    private float timer = 0f;

    void Update()
    {
        timer += Time.deltaTime;

        if (timer >= spawnInterval)
        {
            SpawnObstacle();
            timer = 0f;
        }
    }

    void SpawnObstacle()
    {
        float randomY = Random.Range(minY, maxY);

        Vector3 spawnPosition = new Vector3(spawnX, randomY, 0f);

        Instantiate(obstaclePairPrefab, spawnPosition, Quaternion.identity);
    }
}