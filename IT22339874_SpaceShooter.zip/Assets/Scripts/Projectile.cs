using UnityEngine;

public class Projectile : MonoBehaviour
{
    [Header("Projectile Settings")]
    public float speed = 12f;
    public float lifeTime = 3f;

    void Start()
    {
        Destroy(gameObject, lifeTime);
    }

    void Update()
    {
        transform.Translate(Vector3.right * speed * Time.deltaTime);
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        // Ignore player
        if (other.CompareTag("Player"))
        {
            return;
        }

        // Ignore score zone
        if (other.GetComponent<ScoreZone>() != null)
        {
            return;
        }

        // Ignore health packs
        if (other.GetComponent<HealthPack>() != null)
        {
            return;
        }

        Destroy(gameObject);
    }
}