using TMPro;
using UnityEngine;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour
{
    public static GameManager Instance;

    [Header("UI")]
    public TMP_Text scoreText;
    public GameObject gameOverPanel;

    [Header("Player Reference")]
    public PlayerHealth playerHealth;

    [Header("Game Speed Settings")]
    public float gameSpeed = 4f;
    public float speedIncreaseAmount = 0.2f;
    public float speedIncreaseInterval = 10f;
    public float maxGameSpeed = 8f;

    private int score = 0;
    private bool isGameOver = false;
    private float speedTimer = 0f;

    void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
        }
        else
        {
            Destroy(gameObject);
            return;
        }
    }

    void Start()
    {
        UpdateScoreUI();

        if (gameOverPanel != null)
        {
            gameOverPanel.SetActive(false);
        }
    }

    void Update()
    {
        // Temporary test key for score
        if (Input.GetKeyDown(KeyCode.K))
        {
            AddScore(1);
        }

        // Temporary health test keys
        if (playerHealth != null)
        {
            if (Input.GetKeyDown(KeyCode.H))
            {
                playerHealth.TakeDamage(10);
            }

            if (Input.GetKeyDown(KeyCode.J))
            {
                playerHealth.Heal(10);
            }
        }

        // Restart when dead
        if (isGameOver && Input.GetKeyDown(KeyCode.R))
        {
            RestartGame();
        }

        // Increase game speed over time
        if (!isGameOver)
        {
            speedTimer += Time.deltaTime;

            if (speedTimer >= speedIncreaseInterval)
            {
                gameSpeed += speedIncreaseAmount;
                gameSpeed = Mathf.Clamp(gameSpeed, 0f, maxGameSpeed);
                speedTimer = 0f;

                Debug.Log("Game Speed Increased To: " + gameSpeed);
            }
        }
    }

    public void AddScore(int amount)
    {
        if (isGameOver) return;

        score += amount;
        UpdateScoreUI();
    }

    void UpdateScoreUI()
    {
        if (scoreText != null)
        {
            scoreText.text = "Score: " + score;
        }
    }

    public void GameOver()
    {
        isGameOver = true;

        if (gameOverPanel != null)
        {
            gameOverPanel.SetActive(true);
        }
    }

    public void RestartGame()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
    }
}