using UnityEngine;

public class PlayerShooting : MonoBehaviour
{
    [Header("References")]
    public GameObject projectilePrefab;
    public Transform firePoint;

    [Header("Shooting Settings")]
    public float shootCooldown = 0.25f;

    private float shootTimer = 0f;
    private PlayerHealth playerHealth;

    void Start()
    {
        playerHealth = GetComponent<PlayerHealth>();
    }

    void Update()
    {
        shootTimer += Time.deltaTime;

        if (playerHealth != null && playerHealth.currentHealth <= 0)
        {
            return;
        }

        if (Input.GetMouseButtonDown(0) && shootTimer >= shootCooldown)
        {
            Shoot();
            shootTimer = 0f;
        }
    }

    void Shoot()
    {
        if (projectilePrefab == null || firePoint == null)
        {
            return;
        }

        if (SoundManager.Instance != null)
        {
            SoundManager.Instance.PlayShootSound();
        }

        Instantiate(projectilePrefab, firePoint.position, Quaternion.identity);
    }
}