using UnityEngine;

public class HealthPack : MonoBehaviour
{
    [Header("Healing Settings")]
    public int healAmount = 20;

    [Header("Destroy Settings")]
    public float maxLifetime = 12f;
    public float destroyBehindPlayerDistance = 2f;

    private Transform player;

    void Start()
    {
        GameObject playerObject = GameObject.FindGameObjectWithTag("Player");

        if (playerObject != null)
        {
            player = playerObject.transform;
        }

        // Safety destroy in case something goes wrong
        Destroy(gameObject, maxLifetime);
    }

    void Update()
    {
        // Destroy shortly after the player has gone past it
        if (player != null && transform.position.x < player.position.x - destroyBehindPlayerDistance)
        {
            Destroy(gameObject);
        }
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
        {
            PlayerHealth playerHealth = other.GetComponent<PlayerHealth>();

            if (playerHealth != null)
            {
                playerHealth.Heal(healAmount);
            }

            Destroy(gameObject);
        }
    }
}