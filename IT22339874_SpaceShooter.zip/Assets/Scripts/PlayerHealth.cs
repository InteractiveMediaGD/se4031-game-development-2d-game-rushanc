using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class PlayerHealth : MonoBehaviour
{
    [Header("Health Settings")]
    public int maxHealth = 100;
    public int currentHealth;

    [Header("UI")]
    public Slider healthSlider;
    public TMP_Text healthText;
    public Image healthFillImage;

    [Header("Flash Effect")]
    public SpriteRenderer playerSprite;
    public float flashDuration = 0.12f;
    public Color damageFlashColor = Color.red;
    public Color healFlashColor = Color.green;

    private PlayerController playerController;
    private bool isDead = false;

    private Color originalColor;
    private float flashTimer = 0f;

    void Start()
    {
        playerController = GetComponent<PlayerController>();
        currentHealth = maxHealth;

        if (playerSprite == null)
        {
            playerSprite = GetComponent<SpriteRenderer>();
        }

        if (playerSprite != null)
        {
            originalColor = playerSprite.color;
        }

        UpdateHealthUI();
    }

    void Update()
    {
        if (flashTimer > 0f)
        {
            flashTimer -= Time.deltaTime;

            if (flashTimer <= 0f && playerSprite != null)
            {
                playerSprite.color = originalColor;
            }
        }
    }

    public void TakeDamage(int amount)
    {
        if (isDead) return;

        currentHealth -= amount;
        currentHealth = Mathf.Clamp(currentHealth, 0, maxHealth);

        UpdateHealthUI();
        FlashColor(damageFlashColor);

        if (currentHealth <= 0)
        {
            Die();
        }
    }

    public void Heal(int amount)
    {
        if (isDead) return;

        currentHealth += amount;
        currentHealth = Mathf.Clamp(currentHealth, 0, maxHealth);

        UpdateHealthUI();
        FlashColor(healFlashColor);
    }

    void Die()
    {
        isDead = true;

        if (playerController != null)
        {
            playerController.SetCanMove(false);
        }

        if (SoundManager.Instance != null)
        {
        SoundManager.Instance.PlayGameOverSound();
     }

        if (GameManager.Instance != null)
        {
            GameManager.Instance.GameOver();
        }
    }

    void UpdateHealthUI()
    {
        if (healthSlider != null)
        {
            healthSlider.maxValue = maxHealth;
            healthSlider.value = currentHealth;
        }

        if (healthText != null)
        {
            healthText.text = currentHealth + " / " + maxHealth;
        }

        if (healthFillImage != null)
        {
            float healthPercent = (float)currentHealth / maxHealth;
            healthFillImage.color = Color.Lerp(Color.red, Color.green, healthPercent);
        }
    }

    void FlashColor(Color flashColor)
    {
        if (playerSprite != null)
        {
            playerSprite.color = flashColor;
            flashTimer = flashDuration;
        }
    }
}